import React from 'react';

class Footer extends React.Component {
  render() {
   
    return (
      <div >
        <div class="fixed-bottom d-flex justify-content-between border-top"> Shiggi Jam | Organic Skincare - Created by James Thomas McNeil</div>
      </div>
    )
  }
}

export default Footer
